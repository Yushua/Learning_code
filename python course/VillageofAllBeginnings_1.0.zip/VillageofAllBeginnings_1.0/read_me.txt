-=-=-=- -==-=- -==-=- -==-=- -==-=-
PIXELARIUM - Village of All Beginnings & Animated Character
-==-=- -==-=- -==-=- -==-=- -==-=-

Thank you for your support!

-------------------------

This is the very first pack from the PIXELARIUM tileset collection.

This pack includes:
- the Village of All Beginning tileset v 1.0
- Animated Character v 1.0

Release date: March 21st 2021

Important note: there may be slight differences between the versions, as well as new tiles.
Make sure to check out the latest version of the pack on ric-gamedev.itch.io/pixelarium

-------------------------
License:
All tilesets from PIXELARIUM can be edited and used for personal and commercial use.
Credit is not necessary but it is highly appreciated. I'd love to see what you create with it :)

-------------------------
Want to support my work? Send a ko-fi (or two!): ko-fi.com/ric_gamedev

-------------------------
YouTube
  youtube.com/c/Ric_Devlogs
-------------------------